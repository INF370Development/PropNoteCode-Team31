﻿namespace WebApi.Models.Data
{
    public class DataType
    {
        public int DataTypeID { get; set; }
        public string DataTypeName { get; set; }
    }
}
