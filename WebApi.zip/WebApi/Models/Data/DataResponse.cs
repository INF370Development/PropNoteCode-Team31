﻿namespace WebApi.Models.Data
{
    public class DataResponse
    {
        public int DataID { get; set; }
        public string? DataDescription { get; set; }
        public string? EmployeeName { get; set; }
    }
}
