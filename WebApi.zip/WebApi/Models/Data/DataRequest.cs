﻿namespace WebApi.Models.Data
{
    public class DataRequest
    {
        public string DataDescription { get; set; }
        public int DataTypeID { get; set; }
        public int EmployeeID { get; set; }
    }
}
