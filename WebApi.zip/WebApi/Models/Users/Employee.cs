﻿namespace WebApi.Models.Users
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public int ScheduleID { get; set; }
        public string JobTitle { get; set; }
    }
}
