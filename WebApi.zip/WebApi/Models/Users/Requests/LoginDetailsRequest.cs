﻿namespace WebApi.Models.Users.Requests
{
    public class LoginDetailsRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}