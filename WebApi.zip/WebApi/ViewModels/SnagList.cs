﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Admin
{
    public class SnagListViewModel
    {
        public int PropertyId { get; set; }
        public string SnagListDescription { get; set; }
    }
}
