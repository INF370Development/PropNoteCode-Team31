﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Maintenance
{
    public class MaintenanceStatusViewModel
    {
        public string MaintenaceStatusName { get; set; }

    }
}
