﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Admin
{
    public class SnagListItemLineViewModel
    {
        public int SnagListId { get; set; }
        public int SnagListItemsId { get; set; }

    }
}
