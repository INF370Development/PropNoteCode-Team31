﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Admin
{
    public class ContractorTypeViewModel
    {
        public string ContractorTypeName { get; set; } = string.Empty;
    }
}
