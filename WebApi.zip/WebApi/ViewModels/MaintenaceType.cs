﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Maintenance
{
    public class MaintenanceTypeViewModel
    {
        public string MaintenaceTypeName { get; set; }

    }
}
