﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Admin
{
    public class SnagListItemViewModel
    {
        public string SnagListItemDescription { get; set; } = string.Empty;
    }
}
