﻿namespace WebApi.ViewModels
{
    public class UserViewModel
    {
    }
}
