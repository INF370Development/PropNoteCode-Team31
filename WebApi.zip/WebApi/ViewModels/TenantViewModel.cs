﻿namespace WebApi.ViewModels
{
    public class TenantViewModel
    {
        public int TenantID { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string JobTitle { get; set; }
    }
}
