﻿namespace WebApi.ViewModels
{
    public class DataTypeViewModel
    {
        public string DataTypeName { get; set; }
    }
}
