﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Maintenance
{
    public class MaintenanceContractorLineViewModel
    {
        public int MaintenaceID { get; set; }
        public int ContractorID { get; set; }

    }
}
